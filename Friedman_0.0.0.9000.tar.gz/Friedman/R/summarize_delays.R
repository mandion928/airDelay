#' Summarize airline delays
#'
#' Calculates average arrival delay by airline.
#'
#' @param data A data frame containing airline delay data.
#' @param airline_col The name of the airline column.
#' @param delay_col The name of the arrival delay column.
#'
#' @return A summary data frame with average delay by airline.
#' @export
summarize_delays <- function(data, airline_col, delay_col) {
  data |>
    dplyr::group_by(rlang::.data[[airline_col]]) |>
    dplyr::summarise(
      average_delay = mean(rlang::.data[[delay_col]], na.rm = TRUE),
      .groups = "drop"
    )
}
